package com.makeveryday.ahnjunhyeock.appcopystudy.Main;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentContainer;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentBeauty;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentEntertainment;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentLifeStyle;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentRanking;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentRecipe;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentTimeLine;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentTop;
import com.makeveryday.ahnjunhyeock.appcopystudy.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.makeveryday.ahnjunhyeock.appcopystudy.R.layout.fragment_beauty;
import static com.makeveryday.ahnjunhyeock.appcopystudy.R.layout.fragment_entertainment;
import static com.makeveryday.ahnjunhyeock.appcopystudy.R.layout.fragment_life_style;
import static com.makeveryday.ahnjunhyeock.appcopystudy.R.layout.fragment_ranking;
import static com.makeveryday.ahnjunhyeock.appcopystudy.R.layout.fragment_recipe;
import static com.makeveryday.ahnjunhyeock.appcopystudy.R.layout.fragment_time_line;
import static com.makeveryday.ahnjunhyeock.appcopystudy.R.layout.fragment_top;

/**
 * Created by ahnjunhyeock on 2017. 12. 8..
 */

public class ViewPagerAdapter extends FragmentPagerAdapter {

    private static final int NUMBER_OF_LOOPS = 10000;

    protected List<Fragment> fragments = new ArrayList<>();
    protected String[] title = new String[]{
            "ENTERTAINMENT",
            "RANKING",
            "TOP",
            "TIME LINE",
            "BEAUTY",
            "RECIPE",
            "LIFESTYLE",
            "OUTING"
    };

    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
        fragments.add(new FragmentEntertainment());
        fragments.add(new FragmentRanking());
        fragments.add(new FragmentTop());
        fragments.add(new FragmentTimeLine());
        fragments.add(new FragmentBeauty());
        fragments.add(new FragmentRecipe());
        fragments.add(new FragmentLifeStyle());

    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        switch(position % 10) {
            case 0:
                return inflateView(container, R.layout.fragment_entertainment);
            case 1:
                return inflateView(container, R.layout.fragment_ranking);
            case 2:
                return inflateView(container, R.layout.fragment_top);
            case 3:
                return inflateView(container, R.layout.fragment_time_line);
            case 4:
                return inflateView(container, R.layout.fragment_beauty);
            case 5:
                return inflateView(container, R.layout.fragment_recipe);
            case 6:
                return inflateView(container, R.layout.fragment_life_style);
            default:
                return inflateView(container, R.layout.fragment_beauty);
        }
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View)object);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position % fragments.size());
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public String getPageTitle(int position) {
        return title[position % fragments.size()];
    }

    public int getCenterPosition(int position) {
        return fragments.size() * NUMBER_OF_LOOPS / 2 + position;
    }

    @Override
    public int getCount() {
        return fragments.size() * NUMBER_OF_LOOPS;
    }

    public Fragment getValueAt(int position) {
        if (fragments.size() == 0) {
            return null;
        }
        return fragments.get(position % fragments.size());
    }

    private View inflateView(ViewGroup container, int layout) {
        View view = LayoutInflater.from(container.getContext())
                .inflate(layout, container, false);
        //container.addView(view);

        return view;
    }
}
