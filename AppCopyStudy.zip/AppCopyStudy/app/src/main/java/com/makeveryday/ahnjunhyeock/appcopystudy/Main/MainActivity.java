package com.makeveryday.ahnjunhyeock.appcopystudy.Main;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentBeauty;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentEntertainment;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentLifeStyle;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentRanking;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentRecipe;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentTimeLine;
import com.makeveryday.ahnjunhyeock.appcopystudy.FirstTab.FragmentTop;
import com.makeveryday.ahnjunhyeock.appcopystudy.Login.LoginActivity;
import com.makeveryday.ahnjunhyeock.appcopystudy.R;
import com.nshmura.recyclertablayout.RecyclerTabLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ahnjunhyeock on 2017. 12. 3..
 */

public class MainActivity extends AppCompatActivity implements TabLayout.OnTabSelectedListener, ViewPager.OnPageChangeListener {

    private ImageView drawerLoginImg;
    private DrawerLayout drawer;
    private ActionBarDrawerToggle toggle;
    private Toolbar toolBar;
    private ListView listView;
    private NavigationListAdapter navigationListAdapter;
    private ViewPagerAdapter pagerAdapter;
    private RecyclerTabLayout tabLayout;
    private NavigationView navigationView;
    private ViewPager viewPager;

    private int scrollState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolBar = (Toolbar) findViewById(R.id.main_tool_bar);
        setSupportActionBar(toolBar);
        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);
        ab.setTitle(R.string.app_name);
        drawer = (DrawerLayout) findViewById(R.id.main_drawer);
        toggle = new ActionBarDrawerToggle(this,
                drawer,
                toolBar,
                R.string.drawer_open,
                R.string.drawer_close);
        toggle.syncState();

        navigationListAdapter = new NavigationListAdapter();
        listView = (ListView) findViewById(R.id.drawer_list);
        listView.setAdapter(navigationListAdapter);
        navigationListAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.ic_view_module_white_24dp),
                getString(R.string.drawer_text_feed));
        navigationListAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.ic_person_white_24dp),
                getString(R.string.drawer_text_profile));
        navigationListAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.ic_timeline_white_24dp),
                getString(R.string.drawer_text_report));
        navigationListAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.ic_feedback_white_24dp),
                getString(R.string.drawer_text_notice));

        navigationView = (NavigationView) findViewById(R.id.main_navigation_view);
        drawerLoginImg = navigationView.getRootView().findViewById(R.id.drawer_login_img);
        drawerLoginImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        pagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());

        viewPager = (ViewPager) findViewById(R.id.main_view_pager);
        viewPager.setAdapter(pagerAdapter);
        viewPager.setCurrentItem(2);
        viewPager.setCurrentItem(pagerAdapter.getCenterPosition(0));
        viewPager.addOnPageChangeListener(this);

        tabLayout = (RecyclerTabLayout) findViewById(R.id.main_tab);
        tabLayout.setUpWithViewPager(viewPager);

    }


    @Override
    public void onBackPressed() {
        if (this.drawer.isDrawerOpen(GravityCompat.START)) {
            this.drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }

    }

    /*
    ToolBar Menu
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return false;
        }

        return super.onOptionsItemSelected(item);
    }

    /*
    TabLayout
     */
    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }


    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        boolean nearLeftEdge = (position <= pagerAdapter.fragments.size());
        boolean nearRightEdge = (position >= pagerAdapter.getCount() - pagerAdapter.fragments.size());
        if (nearLeftEdge || nearRightEdge) {
            viewPager.setCurrentItem(pagerAdapter.getCenterPosition(2), false);
        }

    }

    @Override
    public void onPageScrollStateChanged(int state) {
        scrollState = state;
    }
}




