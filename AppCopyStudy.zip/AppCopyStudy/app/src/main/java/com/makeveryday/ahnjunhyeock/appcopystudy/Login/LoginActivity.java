package com.makeveryday.ahnjunhyeock.appcopystudy.Login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.makeveryday.ahnjunhyeock.appcopystudy.Main.MainActivity;
import com.makeveryday.ahnjunhyeock.appcopystudy.R;

/**
 * Created by ahnjunhyeock on 2017. 12. 3..
 */

public class LoginActivity extends Activity implements GoogleApiClient.OnConnectionFailedListener {

    TextView loginCheckTxt, loginBarName, loginGTxt, loginFBTxt, loginTTxt, loginNTxt, loginETxt, signUpETxt;
    ImageView loginBarClose, loginGImg, loginFBImg, loginTImg, loginNImg, loginEImg, signUpEImg;
    Toolbar loginBar;
    MainActivity mainActivity;

    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;

    GoogleApiClient googleApiClient;

    String userName;

    final String TAG = LoginActivity.class.getName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();

        loginCheckTxt = (TextView)findViewById(R.id.login_check_txt);
        loginCheckTxt.setText(userName);

        loginBar = (Toolbar)findViewById(R.id.login_bar);
        loginBarName = (TextView)findViewById(R.id.login_bar_name);
        loginBarClose = (ImageView)findViewById(R.id.login_bar_close);
        loginBarClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        loginGTxt = (TextView)findViewById(R.id.login_google_txt);
        loginGImg = (ImageView)findViewById(R.id.login_google_img);
        loginGImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(firebaseUser == null) {
                    Intent intent = new Intent(LoginActivity.this, SignInActivity.class);
                    startActivity(intent);
                } else {
                    userName = firebaseUser.getDisplayName();

                }
            }
        });

        googleApiClient = new GoogleApiClient.Builder(this)
               // .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API)
                .build();

        loginFBTxt = (TextView)findViewById(R.id.login_facebook_txt);
        loginFBImg = (ImageView)findViewById(R.id.login_facebook_img);

        loginTTxt = (TextView)findViewById(R.id.login_twitter_txt);
        loginTImg = (ImageView)findViewById(R.id.login_twitter_img);

        loginNTxt = (TextView)findViewById(R.id.login_naver_txt);
        loginNImg = (ImageView)findViewById(R.id.login_naver_img);

        loginETxt = (TextView)findViewById(R.id.login_mail_txt);
        loginEImg = (ImageView)findViewById(R.id.login_mail_img);

        signUpETxt = (TextView)findViewById(R.id.login_mail_txt2);
        signUpEImg = (ImageView)findViewById(R.id.login_mail_img2);

        return ;
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.d(TAG, "onConnectionFailed:" + connectionResult);
    }
}


