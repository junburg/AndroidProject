package com.makeveryday.ahnjunhyeock.appcopystudy.Main;

import android.graphics.drawable.Drawable;

/**
 * Created by ahnjunhyeock on 2017. 12. 8..
 */

public class NavigationListItem {

    private Drawable navigationListImg;
    private String navigationListTxt;

    public void setIcon(Drawable icon) {
        navigationListImg = icon;
    }

    public void setTitle(String title) {
        navigationListTxt = title;
    }

    public Drawable getIcon() {
        return navigationListImg;
    }

    public String getTitle() {
        return navigationListTxt;
    }

}
