package com.makeveryday.ahnjunhyeock.appcopystudy.Main;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.makeveryday.ahnjunhyeock.appcopystudy.Login.LoginActivity;
import com.makeveryday.ahnjunhyeock.appcopystudy.R;

import java.util.ArrayList;

/**
 * Created by ahnjunhyeock on 2017. 12. 8..
 */

public class NavigationListAdapter extends BaseAdapter {
    ImageView navigationListImg;
    TextView navigationListTxt;

    private ArrayList<NavigationListItem> navigationItemList = new ArrayList<NavigationListItem>();

    public NavigationListAdapter() {

    }

    @Override
    public int getCount() {
        return navigationItemList.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.navigation_view_list_custom, parent, false);
        }

        navigationListImg = (ImageView) convertView.findViewById(R.id.navigation_list_img);
        navigationListTxt = (TextView) convertView.findViewById(R.id.navigation_list_txt);


        NavigationListItem navigationListItem = navigationItemList.get(position);

        navigationListImg.setImageDrawable(navigationListItem.getIcon());
        navigationListTxt.setText(navigationListItem.getTitle());


        return convertView;
    }

    @Override
    public Object getItem(int position) {
        return navigationItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void addItem(Drawable icon, String title) {

        NavigationListItem item = new NavigationListItem();
        item.setIcon(icon);
        item.setTitle(title);
        navigationItemList.add(item);
    }
}
